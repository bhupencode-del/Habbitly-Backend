export class LoginUserDto {
    email?: string;
    phoneNumber?: string;
    password: string;
  }
  