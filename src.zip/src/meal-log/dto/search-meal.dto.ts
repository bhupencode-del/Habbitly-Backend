// src/meal-log/dto/search-meal.dto.ts
export class SearchMealDto {
    query: string;
  }
  