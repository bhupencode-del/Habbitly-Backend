export class TrackHabitDto {
    date: string; // Format: YYYY-MM-DD
  }
  