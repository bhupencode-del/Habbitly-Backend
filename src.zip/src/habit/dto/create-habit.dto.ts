export class CreateHabitDto {
    name: string;
    repeat: string;
    reminderTime: string;
    startDate: string;
    notes?: string;
  }
  